# EcoNest Task 4 — Maven project

This is the uploaded Task 4 delivery-agent CRUD application reorganized into the Maven folder layout.

## Included
- `Main.java` — application entry point
- `Agent.java` — delivery-agent model
- `AgentManager.java` — JDBC CRUD/search operations
- `AgentFrame.java` — Swing user interface
- `DBConnection.java` — MySQL connection helper
- `src/main/resources/db/schema.sql` and `seed.sql`

## Run
1. Start MySQL and execute `schema.sql`, then `seed.sql` in phpMyAdmin or MySQL Workbench.
2. Open the project folder containing `pom.xml` in IntelliJ IDEA or another Maven-capable IDE.
3. Update MySQL credentials in `DBConnection.java` if needed.
4. Run `econest.Main`.

The uploaded ZIP contained only Task 4 files. The other EcoNest modules shown in your target tree (products, inventory, clients, vehicles, orders, delivery assignments, reports and tests) were not present, so they have not been fabricated.
