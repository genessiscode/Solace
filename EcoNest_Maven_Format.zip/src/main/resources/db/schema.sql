CREATE DATABASE IF NOT EXISTS econest;
USE econest;

CREATE TABLE IF NOT EXISTS delivery_agents (
    agent_id VARCHAR(20) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    phone VARCHAR(10) NOT NULL,
    address VARCHAR(255) NOT NULL,
    vehicle_number VARCHAR(30) NOT NULL,
    vehicle_type VARCHAR(30) NOT NULL,
    status VARCHAR(20) NOT NULL
);
