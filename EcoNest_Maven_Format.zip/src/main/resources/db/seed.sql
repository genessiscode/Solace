INSERT INTO delivery_agents
(agent_id, name, phone, address, vehicle_number, vehicle_type, status)
VALUES
('DA001', 'Kasun Perera', '0771234567', 'Colombo', 'WP CAB-1234', 'Van', 'Available'),
('DA002', 'Nimal Silva', '0712345678', 'Kotte', 'WP CBA-5678', 'Motorcycle', 'Available');
